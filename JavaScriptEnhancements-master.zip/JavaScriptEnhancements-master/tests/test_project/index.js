// @flow
/*
  * flowlint
  *   sketchy-null: warn
*/

let unused_variable = 2

const x: ?number = 5
if (x) {}

y