### Expected Behavior


### Actual Behavior


### Sublime Text console logs 
<!-- to see the Sublime Text console logs, go to View > Show Console, then copy and paste here eventual errors -->

### Screenshots
<!-- post here screenshots/gifs that may help to understand the problem -->

### Steps to Reproduce the Problem

1.
1.
1.

### Specifications

- Sublime Text 3 build:
- OS:
- JavaScript Enhancements version: 
<!-- to see the plugin version, go to Preferences > Package Settings > JavaScript Enhancements > Version -->